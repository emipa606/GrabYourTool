# CM_Grab_Your_Tool
 This Rimworld mod makes pawns equip a tool related to their job if they have one in their inventory.
